flag = 'KCSC{XXXXXXXXXXXX}'
binary_flag = []

for char in flag:
    binary_char = bin(ord(char))[2:].zfill(8)
    binary_flag.append(binary_char)

binary_flag = ' '.join(binary_flag)  

print(binary_flag)
