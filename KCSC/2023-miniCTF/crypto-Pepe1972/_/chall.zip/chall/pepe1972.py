def coordinates(x,y):
    x_fake = 1890*x + 1945*y
    y_fake = 1954*x + 1975*y
    return(x_fake,y_fake)
    
    
flag = 'KCSC{x_y}'
x = ?
y = ?
x,y = coordinates(x,y)
print(x,y)